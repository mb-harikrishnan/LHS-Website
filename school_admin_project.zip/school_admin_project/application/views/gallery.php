<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Public URL of the folder where images are saved.
 * Controller saves to '../assets/images/gallery/' (one level above this admin folder),
 * so we take the parent of base_url(). Change it if your setup is different.
 */
$img_base = dirname(rtrim(base_url(), '/')) . '/assets/images/gallery/';

$gradients = array(
    'linear-gradient(135deg,#3b82f6,#1d4ed8)',
    'linear-gradient(135deg,#059669,#047857)',
    'linear-gradient(135deg,#d97706,#b45309)',
    'linear-gradient(135deg,#7c3aed,#5b21b6)',
    'linear-gradient(135deg,#64748b,#334155)'
);
?>

<!-- Page Content -->
<main class="page">

  <!-- Page Header -->
  <div class="page-header">
    <div>
      <h1 class="page-title">Photo &amp; Event Gallery</h1>
      <p class="page-sub">Campus events, cultural fests, tournaments and celebratory albums</p>
    </div>
    <div class="page-actions">
      <button class="btn" type="button" id="openNewAlbum">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
        Add Album
      </button>
      <button class="btn btn-primary" type="button" id="openAlbumModal">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
        Add Images
      </button>
    </div>
  </div>

  <!-- Gallery Grid (one card per album) -->
  <div class="gallery-grid" id="galleryGrid">
    <?php if (!empty($albums)): ?>
      <?php foreach ($albums as $i => $a): ?>
        <?php
          $has_cover = !empty($a->cover);
          $thumb_style = $has_cover
              ? "background-image:url('" . html_escape($img_base . $a->cover) . "')"
              : 'background:' . $gradients[$i % count($gradients)];
          $total = (int) $a->total;
        ?>
   <div class="gallery-card-wrap">
  <a class="gallery-card-link" href="<?= site_url('gallery_album/' . (int) $a->type_id) ?>">
    <div class="gallery-card">
      <div class="gallery-thumb <?= $has_cover ? 'has-img' : '' ?>" style="<?= $thumb_style ?>">
        <?= $has_cover ? '' : html_escape($a->name) ?>
        <span><?= $total ?> <?= $total === 1 ? 'Photo' : 'Photos' ?></span>
      </div>
      <div class="gallery-info">
        <h3><?= html_escape($a->name) ?></h3>
        <p>
          <?= $a->last_date
              ? 'Last updated ' . date('d M Y', strtotime($a->last_date))
              : 'No photos added yet' ?>
        </p>
        <div class="gallery-meta">
          <span class="badge badge-purple">Album</span>
          <span class="badge <?= $total > 0 ? 'badge-ok' : 'badge-muted' ?>">
            <?= $total > 0 ? 'Active' : 'Empty' ?>
          </span>
        </div>
      </div>
    </div>
  </a>

  <button type="button" class="album-del"
          data-delete-album="<?= (int) $a->type_id ?>"
          data-name="<?= html_escape($a->name) ?>"
          title="Delete album" aria-label="Delete album">&times;</button>
</div>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="empty-note">No albums yet. Click <strong>Add Album</strong> to create one.</p>
    <?php endif; ?>
  </div>
</main>


<!-- ===================== Add Album Modal ===================== -->
<div class="modal-overlay" id="newAlbumModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="newAlbumTitle">
    <div class="modal-head">
      <h2 id="newAlbumTitle">Add Album</h2>
      <button class="modal-close" type="button" data-close-album aria-label="Close">&times;</button>
    </div>

    <form id="newAlbumForm" novalidate>
      <div class="modal-body">
        <label class="field-label" for="nName">Album name <span class="req">*</span></label>
        <input type="text" id="nName" class="field-input" maxlength="100" placeholder="e.g. Sports Day 2026" autocomplete="off">

        <label class="field-label" for="nCover">Cover image <span class="req">*</span></label>
        <label class="dropzone" id="nDrop" for="nCover">
          <img id="nPrev" alt="" hidden style="max-height:140px;max-width:100%;border-radius:8px">
          <span id="nHint"><strong>Click to choose</strong> or drag the cover image here</span>
          <small>JPG, PNG, WEBP · max 5 MB</small>
        </label>
        <input type="file" id="nCover" accept="image/png,image/jpeg,image/webp" hidden>

        <p class="field-error" id="nError" hidden></p>
      </div>

      <div class="modal-foot">
        <button type="button" class="btn" data-close-album>Cancel</button>
        <button type="submit" class="btn btn-primary" id="nSubmit">Save Album</button>
      </div>
    </form>
  </div>
</div>


<!-- ===================== Add Images Modal ===================== -->
<div class="modal-overlay" id="albumModal" aria-hidden="true">
  <div class="modal" style="max-width:640px" role="dialog" aria-modal="true" aria-labelledby="albumModalTitle">
    <div class="modal-head">
      <h2 id="albumModalTitle">Add Images</h2>
      <button class="modal-close" type="button" data-close aria-label="Close">&times;</button>
    </div>

    <form id="albumForm" novalidate>
      <div class="modal-body">
        <label class="field-label" for="aCategory">Album <span class="req">*</span></label>
        <select id="aCategory" class="field-input">
          <option value="">Select album</option>
          <?php foreach ($types as $t): ?>
            <option value="<?= (int) $t->slno ?>"><?= html_escape($t->name) ?></option>
          <?php endforeach; ?>
        </select>

        <label class="field-label" for="aFiles">Images <span class="req">*</span></label>
        <label class="dropzone" id="aDrop" for="aFiles">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="1.6"/><path d="m21 15-5-5L5 21"/></svg>
          <span><strong>Click to choose</strong> or drag images here</span>
          <small>JPG, PNG, WEBP · max 5 MB each · up to 30 images</small>
        </label>
        <input type="file" id="aFiles" accept="image/png,image/jpeg,image/webp" multiple hidden>

        <div class="prev-head" id="aCountRow" hidden>
          <span id="aCount"></span>
          <button type="button" class="link-btn" id="aClear">Remove all</button>
        </div>
        <div class="prev-grid" id="aPreview"></div>

        <p class="field-error" id="aError" hidden></p>
      </div>

      <div class="modal-foot">
        <button type="button" class="btn" data-close>Cancel</button>
        <button type="submit" class="btn btn-primary" id="aSubmit">Upload</button>
      </div>
    </form>
  </div>
</div>


<style>

  .gallery-card-wrap{position:relative}
.album-del{position:absolute;top:10px;right:10px;width:30px;height:30px;border:0;border-radius:50%;background:rgba(15,23,42,.75);color:#fff;font-size:20px;line-height:1;cursor:pointer;opacity:0;transition:.15s;display:flex;align-items:center;justify-content:center;z-index:2}
.gallery-card-wrap:hover .album-del,.album-del:focus{opacity:1}
.album-del:hover{background:#dc2626}
@media (hover:none){.album-del{opacity:1}}
/* ---------- gallery grid ---------- */
.gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px}
.gallery-card-link{text-decoration:none;color:inherit;display:block}
.gallery-card{background:#fff;border:1px solid var(--line);border-radius:16px;overflow:hidden;box-shadow:var(--shadow-soft);transition:transform .15s ease,box-shadow .15s ease}
.gallery-card:hover{transform:translateY(-2px);box-shadow:var(--shadow-lift)}
.gallery-thumb{height:160px;background:linear-gradient(135deg,var(--brand-500),var(--brand-700));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:16px;position:relative;text-align:center;padding:0 12px}
.gallery-thumb span{position:absolute;bottom:10px;right:12px;background:rgba(0,0,0,.4);padding:2px 8px;border-radius:6px;font-size:11px;backdrop-filter:blur(4px)}
.gallery-thumb.has-img{background-size:cover;background-position:center}
.gallery-thumb.has-img::before{content:"";position:absolute;inset:0;background:linear-gradient(transparent 50%,rgba(0,0,0,.45))}
.gallery-thumb.has-img span{z-index:1}
.gallery-info{padding:16px}
.gallery-info h3{font-size:15px;margin:0 0 4px;color:var(--slate-900)}
.gallery-info p{font-size:12.5px;color:var(--slate-500);margin:0 0 12px}
.gallery-meta{display:flex;align-items:center;justify-content:space-between;border-top:1px solid var(--slate-100);padding-top:10px}
.empty-note{grid-column:1/-1;text-align:center;color:#64748b;padding:40px 0}
.page-actions{display:flex;gap:10px;flex-wrap:wrap}

/* ---------- modal ---------- */
.modal-overlay{position:fixed;inset:0;background:rgba(15,23,42,.5);display:none;align-items:center;justify-content:center;padding:16px;z-index:1000}
.modal-overlay.open{display:flex}
.modal{background:#fff;border-radius:12px;width:100%;max-width:480px;max-height:92vh;overflow:auto;box-shadow:0 20px 50px rgba(0,0,0,.25)}
.modal-head{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid #e2e8f0}
.modal-head h2{margin:0;font-size:18px}
.modal-close{background:none;border:0;font-size:26px;line-height:1;cursor:pointer;color:#64748b}
.modal-body{padding:20px}
.modal-foot{display:flex;justify-content:flex-end;gap:10px;padding:14px 20px;border-top:1px solid #e2e8f0}
.field-label{display:block;font-size:13px;font-weight:600;margin:0 0 6px}
.field-label .req{color:#dc2626}
.field-input{width:100%;padding:9px 10px;border:1px solid #cbd5e1;border-radius:8px;font:inherit;margin-bottom:16px;box-sizing:border-box}
.field-input:focus{outline:none;border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.15)}
.dropzone{display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center;padding:22px 12px;border:2px dashed #cbd5e1;border-radius:10px;cursor:pointer;color:#64748b;transition:.15s}
.dropzone:hover,.dropzone.drag{border-color:#2563eb;background:#eff6ff}
.field-error{color:#dc2626;font-size:13px;margin:12px 0 0}
.field-error.ok{color:#059669}

/* previews */
.prev-head{display:flex;justify-content:space-between;align-items:center;margin:14px 0 8px;font-size:13px;font-weight:600}
.link-btn{background:none;border:0;color:#dc2626;font-size:13px;cursor:pointer;padding:0}
.link-btn:hover{text-decoration:underline}
.prev-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:10px}
.prev-item{position:relative;aspect-ratio:1/1;border-radius:10px;overflow:hidden;border:1px solid #e2e8f0;background:#f1f5f9}
.prev-item img{width:100%;height:100%;object-fit:cover;display:block}
.prev-x{position:absolute;top:5px;right:5px;width:22px;height:22px;border:0;border-radius:50%;background:rgba(15,23,42,.75);color:#fff;font-size:15px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center}
.prev-x:hover{background:#dc2626}
.prev-name{position:absolute;left:0;right:0;bottom:0;padding:3px 6px;background:linear-gradient(transparent,rgba(0,0,0,.65));color:#fff;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
</style>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- ===================== Add Album script ===================== -->
<script>
(function () {
  const $ = id => document.getElementById(id);
  const modal = $('newAlbumModal'), form = $('newAlbumForm');
  const nameEl = $('nName'), fileEl = $('nCover'), drop = $('nDrop');
  const prev = $('nPrev'), hint = $('nHint'), err = $('nError'), btn = $('nSubmit');
  const MAX = 5 * 1024 * 1024, OK = ['image/jpeg', 'image/png', 'image/webp'];

  // CSRF (CodeIgniter) - updated after every AJAX response
  let csrfName = '<?= $this->security->get_csrf_token_name() ?>';
  let csrfHash = '<?= $this->security->get_csrf_hash() ?>';
  const URL_SAVE = '<?= site_url('save_album') ?>';
  let cover = null;

  const showErr = t => { err.classList.remove('ok'); err.textContent = t; err.hidden = false; };
  const showOk  = t => { err.classList.add('ok');    err.textContent = t; err.hidden = false; };

  function setCover(f) {
    err.hidden = true;
    if (!f) return;
    if (!OK.includes(f.type)) return showErr('Only JPG, PNG or WEBP images are allowed.');
    if (f.size > MAX)         return showErr('Image is larger than 5 MB.');
    if (prev.src) URL.revokeObjectURL(prev.src);
    cover = f;
    prev.src = URL.createObjectURL(f);
    prev.hidden = false;
    hint.textContent = f.name;
  }

  function open()  { modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false'); nameEl.focus(); }
  function close() {
    modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true');
    form.reset(); cover = null; err.hidden = true;
    if (prev.src) URL.revokeObjectURL(prev.src);
    prev.removeAttribute('src'); prev.hidden = true;
    hint.innerHTML = '<strong>Click to choose</strong> or drag the cover image here';
  }

  $('openNewAlbum').addEventListener('click', open);
  modal.addEventListener('click', e => { if (e.target === modal || e.target.closest('[data-close-album]')) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) close(); });

  fileEl.addEventListener('change', () => { setCover(fileEl.files[0]); fileEl.value = ''; });
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('drag'); }));
  drop.addEventListener('drop', e => setCover(e.dataTransfer.files[0]));

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const name = nameEl.value.trim();
    if (!name)  return showErr('Please enter the album name.');
    if (!cover) return showErr('Please choose a cover image.');

    const data = new FormData();
    data.append('name', name);
    data.append('cover', cover);
    data.append(csrfName, csrfHash);

    btn.disabled = true; btn.textContent = 'Saving...'; err.hidden = true;

    try {
      const res  = await fetch(URL_SAVE, { method: 'POST', body: data, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const json = await res.json();
      if (json.csrf) csrfHash = json.csrf;

      if (json.status) {
        showOk(json.msg);
        setTimeout(() => window.location.reload(), 800);
      } else {
        showErr(json.msg || 'Could not save.');
        btn.disabled = false; btn.textContent = 'Save Album';
      }
    } catch (x) {
      showErr('Something went wrong. Please try again.');
      btn.disabled = false; btn.textContent = 'Save Album';
    }
  });
})();
</script>


<!-- ===================== Add Images script ===================== -->
<script>
(function () {
  const $ = id => document.getElementById(id);
  const modal = $('albumModal'), form = $('albumForm');
  const input = $('aFiles'), drop = $('aDrop'), preview = $('aPreview');
  const countRow = $('aCountRow'), countEl = $('aCount'), errorEl = $('aError');
  const submitBtn = $('aSubmit');

  const MAX_SIZE = 5 * 1024 * 1024, MAX_FILES = 30;
  const OK_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

  let csrfName = '<?= $this->security->get_csrf_token_name() ?>';
  let csrfHash = '<?= $this->security->get_csrf_hash() ?>';
  const UPLOAD_URL = '<?= site_url('save_gallery_images') ?>';

  let items = [];   // [{ id, file, url }]
  let uid = 0;

  const esc = s => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const showError = t => { errorEl.classList.remove('ok'); errorEl.textContent = t; errorEl.hidden = false; };
  const showOk    = t => { errorEl.classList.add('ok');    errorEl.textContent = t; errorEl.hidden = false; };

  function render() {
    preview.innerHTML = items.map(it => `
      <div class="prev-item">
        <img src="${it.url}" alt="">
        <button type="button" class="prev-x" data-remove="${it.id}" title="Remove" aria-label="Remove image">&times;</button>
        <div class="prev-name">${esc(it.file.name)}</div>
      </div>`).join('');
    countRow.hidden = items.length === 0;
    countEl.textContent = items.length + (items.length === 1 ? ' image selected' : ' images selected');
  }

  function addFiles(fileList) {
    errorEl.hidden = true;
    const problems = [];
    for (const f of fileList) {
      if (items.length >= MAX_FILES) { problems.push('Maximum ' + MAX_FILES + ' images at a time.'); break; }
      if (!OK_TYPES.includes(f.type)) { problems.push(f.name + ': only JPG, PNG or WEBP images are allowed.'); continue; }
      if (f.size > MAX_SIZE) { problems.push(f.name + ': larger than 5 MB.'); continue; }
      if (items.some(x => x.file.name === f.name && x.file.size === f.size && x.file.lastModified === f.lastModified)) continue;
      items.push({ id: ++uid, file: f, url: URL.createObjectURL(f) });
    }
    render();
    if (problems.length) showError(problems.slice(0, 3).join(' ') + (problems.length > 3 ? ' (+' + (problems.length - 3) + ' more)' : ''));
  }

  function clearItems() {
    items.forEach(it => URL.revokeObjectURL(it.url));
    items = []; render();
  }

  function open() { modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false'); $('aCategory').focus(); }
  function close() {
    modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true');
    form.reset(); errorEl.hidden = true; clearItems();
  }

  $('openAlbumModal').addEventListener('click', open);
  modal.addEventListener('click', e => { if (e.target === modal || e.target.closest('[data-close]')) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) close(); });

  input.addEventListener('change', () => { addFiles(input.files); input.value = ''; });
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('drag'); }));
  drop.addEventListener('drop', e => addFiles(e.dataTransfer.files));

  preview.addEventListener('click', e => {
    const btn = e.target.closest('[data-remove]'); if (!btn) return;
    const id = Number(btn.dataset.remove);
    const it = items.find(x => x.id === id);
    if (it) URL.revokeObjectURL(it.url);
    items = items.filter(x => x.id !== id);
    errorEl.hidden = true;
    render();
  });
  $('aClear').addEventListener('click', () => { clearItems(); errorEl.hidden = true; });

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const type = $('aCategory').value;
    if (!type) return showError('Please select an album.');
    if (!items.length) return showError('Please add at least one image.');

    const data = new FormData();
    data.append('type', type);
    data.append(csrfName, csrfHash);
    items.forEach(it => data.append('images[]', it.file));

    submitBtn.disabled = true;
    submitBtn.textContent = 'Uploading...';
    errorEl.hidden = true;

    try {
      const res  = await fetch(UPLOAD_URL, { method: 'POST', body: data, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const json = await res.json();
      if (json.csrf) csrfHash = json.csrf;

      if (json.status) {
        showOk(json.msg);
        setTimeout(() => window.location.reload(), 900);
      } else {
        showError(json.msg || 'Upload failed.');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Upload';
      }
    } catch (err) {
      showError('Something went wrong. Please try again.');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Upload';
    }
  });
})();
</script>

<script>
(function () {
  let csrfName = '<?= $this->security->get_csrf_token_name() ?>';
  let csrfHash = '<?= $this->security->get_csrf_hash() ?>';
  const grid = document.getElementById('galleryGrid');
  if (!grid) return;

  grid.addEventListener('click', async e => {
    const btn = e.target.closest('[data-delete-album]'); if (!btn) return;

    // "Are you sure?" popup
    const ask = await Swal.fire({
      title: 'Are you sure?',
      text: 'Delete album "' + btn.dataset.name + '"? This cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc2626',
      cancelButtonColor: '#64748b',
      confirmButtonText: 'Yes, delete it',
      cancelButtonText: 'Cancel'
    });
    if (!ask.isConfirmed) return;

    const body = new FormData();
    body.append('id', btn.dataset.deleteAlbum);
    body.append(csrfName, csrfHash);
    btn.disabled = true;

    try {
      const res  = await fetch('<?= site_url('delete_album') ?>', {
        method: 'POST', body, headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      const json = await res.json();
      if (json.csrf) csrfHash = json.csrf;

      if (!json.status) {
        Swal.fire({ icon: 'error', title: 'Oops', text: json.msg });
        btn.disabled = false;
        return;
      }

      // "Done" popup, then reload
      await Swal.fire({
        icon: 'success',
        title: 'Deleted!',
        text: json.msg,
        timer: 1200,
        showConfirmButton: false
      });
      window.location.reload();

    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Network error', text: 'Please try again.' });
      btn.disabled = false;
    }
  });
})();
</script>